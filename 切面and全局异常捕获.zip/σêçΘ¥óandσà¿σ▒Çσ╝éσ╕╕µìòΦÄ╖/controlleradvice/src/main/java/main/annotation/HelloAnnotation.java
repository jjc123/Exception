package main.annotation;


import java.lang.annotation.*;

/**
 * @author apple
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD,ElementType.METHOD})
@Documented
public @interface HelloAnnotation {
    public String getName() default "helloAnnotation";
    public boolean getIsHello() default false;
}
