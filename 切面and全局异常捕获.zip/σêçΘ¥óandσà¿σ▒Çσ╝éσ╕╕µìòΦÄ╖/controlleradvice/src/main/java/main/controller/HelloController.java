package main.controller;

import main.annotation.HelloAnnotation;
import main.service.Exception;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

/**
 * 〈〉
 *
 * @author jiacong.jiang
 * @create 2020/9/10
 * @since 1.0.0
 */
@Controller
@RequestMapping("/hello")
public class HelloController {

    @Resource
    private Exception exception;

    @ResponseBody
    @RequestMapping(value = "exception", method = RequestMethod.GET)
    @HelloAnnotation(getIsHello = true)
    public String outException(){

        exception.outException();
        return "hello";
    }

    @ResponseBody
    @RequestMapping(value = "aspect", method = RequestMethod.GET)
    @HelloAnnotation(getIsHello = true)
    public String outAspect(){

        return "hello";
    }
}
