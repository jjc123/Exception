package main.aspect;

import main.annotation.HelloAnnotation;
import main.service.Exception;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 〈〉
 *
 * @author jiacong.jiang
 * @create 2020/9/10
 * @since 1.0.0
 */
@Aspect
@Component
public class HelloAspect {


    @AfterReturning(pointcut = "@annotation(helloAnnotation)",returning = "returnValue")
    public void getHello(JoinPoint joinPoint, HelloAnnotation helloAnnotation, Object returnValue){

        throw new RuntimeException("切面异常");
    }
}
