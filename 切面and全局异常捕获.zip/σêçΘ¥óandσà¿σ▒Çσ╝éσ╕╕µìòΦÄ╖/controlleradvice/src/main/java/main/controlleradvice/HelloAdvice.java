package main.controlleradvice;

import main.dto.HelloDTO;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 〈〉
 *
 * @author jiacong.jiang
 * @create 2020/9/10
 * @since 1.0.0
 */
@ControllerAdvice
public class HelloAdvice {

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public HelloDTO getException(Exception ex){
        System.out.println(ex.getMessage());
        return HelloDTO.builder()
                .code(1)
                .message("全局捕获异常").build();
    }
}
