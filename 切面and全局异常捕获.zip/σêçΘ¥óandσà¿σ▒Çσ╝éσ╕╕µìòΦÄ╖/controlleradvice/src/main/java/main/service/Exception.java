package main.service;

import org.springframework.stereotype.Service;

/**
 * 〈〉
 *
 * @author jiacong.jiang
 * @create 2020/9/10
 * @since 1.0.0
 */
@Service
public class Exception {

    public void outException(){
        throw new RuntimeException("service Exception");
    }
}
